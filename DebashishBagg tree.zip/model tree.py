import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import time
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
# This function displays the splits of the tree
from sklearn.tree import plot_tree

from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix
from sklearn.metrics import recall_score, precision_score, f1_score, accuracy_score
# Import GridSearchCV
from sklearn.model_selection import GridSearchCV


def make_results(model_name, model_object):
    '''
    Accepts as arguments a model name (your choice - string) and
    a fit GridSearchCV model object.

    Returns a pandas df with the F1, recall, precision, and accuracy scores
    for the model with the best mean F1 score across all validation folds.
    '''
    # Get all the results from the CV and put them in a df
    cv_results = pd.DataFrame(model_object.cv_results_)

    # Isolate the row of the df with the max(mean f1 score)
    best_estimator_results = cv_results.iloc[cv_results['mean_test_f1'].idxmax(), :]

    # Extract accuracy, precision, recall, and f1 score from that row
    f1 = best_estimator_results.mean_test_f1
    recall = best_estimator_results.mean_test_recall
    precision = best_estimator_results.mean_test_precision
    accuracy = best_estimator_results.mean_test_accuracy

    # Create table of results
    table = pd.DataFrame({'Model': [model_name],'F1': [f1],'Recall': [recall],
                              'Precision': [precision],'Accuracy': [accuracy]})
    return table


'''
Code for modelling GST starts here
'''
X_Train = pd.read_csv("X_Train_Data_Input.csv")
Y_Train = pd.read_csv("Y_Train_Data_Target.csv")
X_Test = pd.read_csv("X_Test_Data_Input.csv")
Y_Test = pd.read_csv("Y_Test_Data_Target.csv")


x_train = X_Train[['Column0', 'Column1', 'Column2', 'Column3', 'Column4', 'Column5', 'Column6', 'Column7', 'Column8',
                   'Column9', 'Column10', 'Column11', 'Column12', 'Column13', 'Column14', 'Column15', 'Column16',
                   'Column17', 'Column18', 'Column19', 'Column20', 'Column21']]
y_train = Y_Train['target']
x_test = X_Test[['Column0', 'Column1', 'Column2', 'Column3', 'Column4', 'Column5', 'Column6', 'Column7', 'Column8',
                   'Column9', 'Column10', 'Column11', 'Column12', 'Column13', 'Column14', 'Column15', 'Column16',
                   'Column17', 'Column18', 'Column19', 'Column20', 'Column21']]
y_test = Y_Test['target']

# Instantiate the model
decision_tree = DecisionTreeClassifier(random_state=0)

# Fit the model to training data
decision_tree.fit(x_train, y_train)

# Make predictions on test data
dt_pred = decision_tree.predict(x_test)

# Generate performance metrics
print("Accuracy:", "%.3f" % accuracy_score(y_test, dt_pred))
print("Precision:", "%.3f" % precision_score(y_test, dt_pred))
print("Recall:", "%.3f" % recall_score(y_test, dt_pred))
print("F1 Score:", "%.3f" % f1_score(y_test, dt_pred))
# Create table of results
result_table1 = pd.DataFrame({'Model': ['Decision Tree'],
                              'F1': [f1_score(y_test, dt_pred)],
                              'Recall': [recall_score(y_test, dt_pred)],
                              'Precision': [precision_score(y_test, dt_pred)],
                              'Accuracy': [accuracy_score(y_test, dt_pred)],
                              'Random state': [0]})
'''
Accepts as argument model object, X data (test or validate), and y data (test or validate). 
Returns a plot of confusion matrix for predictions on y data.
'''

cm = confusion_matrix(y_test, dt_pred, labels=decision_tree.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm,
                              display_labels=decision_tree.classes_)

disp.plot(values_format='')  # `values_format=''` suppresses scientific notation
plt.savefig("ConfusionMatrix.jpg")

# Assign a dictionary of hyperparameters to search over
tree_para = {'max_depth':[4,5,6,7,8,9,10,11,12,15,20,30,40,50],
                 'min_samples_leaf': [2, 5, 10, 20, 50]}
# Assign a dictionary of scoring metrics to capture
scoring = ['accuracy', 'precision', 'recall', 'f1']
# Instantiate the classifier
tuned_decision_tree = DecisionTreeClassifier(random_state = 45)
# Instantiate the GridSearch
clf = GridSearchCV(tuned_decision_tree, tree_para, scoring = scoring, cv=5, refit="f1")

# Fit the model
clf.fit(x_train, y_train)
# Examine the best model from GridSearch
print(f"\n Random state: {45}")
print("\n")
print(clf.best_estimator_)

print("\n Best Avg. Validation Score: ", "%.4f" % clf.best_score_)
# Call the function on our model
result_table = make_results("Tuned Decision Tree", clf)
result_table1 = pd.concat([result_table1, result_table])
result_table1 = result_table1.reset_index(drop=True)
result_table1["Random state"].iloc[-1]=45
# View the results
print(result_table1)
